tar -cvf napttestserver.tar /etc/init.d/NaptTestServer /root/naptTestServerForTest/NaptTestServer_Linux.pl /root/naptTestServerForTest/input /tarnapttestserver.sh
